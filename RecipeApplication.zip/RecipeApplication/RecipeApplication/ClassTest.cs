﻿internal class ClassTest
{
    internal void CheckLimit(int i)
    {
        throw new NotImplementedException();
    }
}