﻿using System.Collections.Generic;
public class Program
{
    static RecipeManager recipeManager = new RecipeManager();

    public static void Main(string[] args)
    {
        //generate background color and foreground color
        Console.BackgroundColor = ConsoleColor.DarkBlue;
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("Welcome to RecipeApp!");

        while (true)
        {
            Console.WriteLine("Please select an option:");

            Console.WriteLine("1. Enter a new recipe");
            Console.WriteLine("2. View all recipes");
            Console.WriteLine("3. exit");

            Console.Write("Enter your choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Clear();
                    EnterNewRecipe();
                    break;
                case "2":
                    Console.Clear();
                    ViewAllRecipes();
                    break;
                case "3":
                    Console.WriteLine("Exit");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice!");
                    break;
            }
        }

        static void EnterNewRecipe()
        {
            Console.WriteLine("Enter the details for the new recipe:");

            Console.Write("Recipe Name: ");
            string name = Console.ReadLine();

            Recipe recipe = new Recipe(name);

            Console.Write("Number of Ingredients: ");
            int ingredientCount = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Ingredient {i + 1}:");
                Console.Write("Name: ");
                string ingredientName = Console.ReadLine();
                Console.Write("Quantity: ");
                string quantity = Console.ReadLine();
                Console.Write("Unit of Measurement: ");
                string unit = Console.ReadLine();
                Console.Write("Calories: ");
                int calories = Convert.ToInt32(Console.ReadLine());
                Console.Write("Food Group: ");

                string foodGroup = Console.ReadLine();

                Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
                recipe.AddIngredient(ingredient);
            }

            Console.Write("Number of Steps: ");
            int stepCount = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Step {i + 1}:");
                Console.Write("Description: ");
                string description = Console.ReadLine();

                Step step = new Step(description);

                recipe.AddStep(step);
            }

            recipeManager.AddRecipe(recipe);

            Console.WriteLine("Recipe added successfully!");
        }

        static void ViewAllRecipes()
        {
            List<Recipe> recipes = recipeManager.GetAllRecipes();

            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes found!");
                return;
            }

            Console.WriteLine("Recipes: ");

            foreach (Recipe recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }

            Console.Write("Enter the recipe name: ");
            string recipeName = Console.ReadLine();

            Recipe selectedRecipe = recipeManager.GetRecipe(recipeName);

            if (selectedRecipe != null)
            {
                Console.Clear();
                DisplayRecipe(selectedRecipe);
            }
            else

            {
                Console.WriteLine("Recipe not found!!!");
            }
        }

        static void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine("Recipe Details: ");
            Console.WriteLine($"Name: {recipe.Name} ");

            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Name} - {ingredient.Quantity} {ingredient.Unit} ({ingredient.Calories}calories)");
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                Console.WriteLine($"Step {i + 1}: {recipe.Steps[i].Description}");
            }

            Console.WriteLine();

            DisplayCalories(recipe);
        }

        static void DisplayCalories(Recipe recipe)
        {
            int totalCalories = recipe.CalculateTotalCalories();

            //method to calculate total calories
            Console.WriteLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                //method to notify user when calories exceed 300
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("This recipe exceeds 300 calories!");
                Console.ResetColor();
            }
        }
    }

    class RecipeManager
    {
        private List<Recipe> recipes;

        public RecipeManager()
        {

            recipes = new List<Recipe>();
        }

        public void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
        }

        public List<Recipe> GetAllRecipes()
        {
            recipes.Sort((rp1, rp2) => rp1.Name.CompareTo(rp2.Name));
            return recipes;
        }

        public Recipe GetRecipe(string name)
        {
            return recipes.Find(rp => rp.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

    }

    class Recipe
    {
        public string Name { get; }
        public List<Ingredient> Ingredients { get; }
        public List<Step> Steps { get; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }


        public void AddStep(Step step)
        {
            Steps.Add(step);
        }

        public int CalculateTotalCalories()
        {
            int totalCalories = 0;

            foreach (Ingredient ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }

            return totalCalories;
        }
    }

    class Ingredient
    {
        public string Name { get; }
        public string Quantity { get; }
        public string Unit { get; }
        public int Calories { get; }
        public string FoodGroup { get; }

        public Ingredient(string name, string quantity, string unit, int calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }

    class Step

    {
        public string Description { get; }

        public Step(string descrip)
        {
            Description = descrip;
        }
    }
}
