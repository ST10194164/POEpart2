﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApplication
{
    //class to represent ingredients in the recipe
    internal class Ingredient
    {
        internal int oquantity;
        internal double quantity;

        public string Name { get; }
        public string Quantity { get; }
        public string Unit { get; }
        public int Calories { get; }
        public string FoodGroup { get; }

        public Ingredient(string name, string quantity, string unit, int calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
    //class steps of the recipe
    class Step

    {
        public string Description { get; }

        public Step(string descrip)
        {
            Description = descrip;
        }
    }
}
