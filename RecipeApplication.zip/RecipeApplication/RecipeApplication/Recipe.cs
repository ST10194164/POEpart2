﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApplication
{
    //class representing overall recipe
    internal class Recipe
    {
        public string Name { get; }
        public List<Ingredient> Ingredients { get; }
        public List<Step> Steps { get; }
        public int NumberOfIngredients { get; set; }
        public int NumberOfSteps { get; set; }
        public List<string> steps { get; set; }
        public List<double> Oquantity;
        public List<double> ingredientQ;


        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
            }
        //method to add ingredients
        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }
        //method to add steps
        public void AddStep(Step step)
        {
            NumberOfSteps = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter step details: ");

            for (int i = 0; i < NumberOfSteps; i++)
            {
                Console.WriteLine($"step {i + 1}: ");
                Steps.Add(step);
                steps.Add(Console.ReadLine());
            }
        }
    
private int CalculateTotalCalories()
        {
            int totalCalories = 0;

            foreach (Ingredient ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }

            return totalCalories;
        }
    }
}
