namespace RecipeAppTest
{
    [TestClass]
    public class CheckLimit
    {
        [TestMethod]
        public void TestMethod1()
        {
            //arrange
            int calorieLimit = 300;

            ClassTest recipeAppTest = new ClassTest();

            //act and assert
            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => recipeAppTest.CheckLimit(calorieLimit));
        }
    }
}