﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeAppTest
{
    public class ClassTest
    {
        private const int calorieLimit = 300;

            public void CheckLimit(int calorieLimit)
        {
            if(calorieLimit < 0)
            {
                throw new ArgumentOutOfRangeException("calorieLimit",calorieLimit,"the value is less than zero");
            }
            if(calorieLimit > calorieLimit)
            {
                throw new ArgumentOutOfRangeException("calorieLimit");
            }
        }
    }
}
